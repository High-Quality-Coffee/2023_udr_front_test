from django.apps import AppConfig


class MappingDjangoAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mapping_django_app'

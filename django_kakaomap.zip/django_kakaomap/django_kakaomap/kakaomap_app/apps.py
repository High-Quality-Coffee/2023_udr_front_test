from django.apps import AppConfig


class KakaomapAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kakaomap_app'
